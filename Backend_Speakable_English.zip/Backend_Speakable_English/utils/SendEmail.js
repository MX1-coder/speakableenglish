const sgMail = require('@sendgrid/mail')

const SendEmail = async (email,username) => {
        sgMail.setApiKey(SendgridApiKey)
        const msg = {
            to:email,
            from:{
            name:"Speakable English Project",
            email:process.env.Sender_Email
            },
            templateId:process.env.Template_ID,
            dynamicTemplateData:{
            name:username
            }
        }
        try {
            const sendedmessage =  await sgMail.send(msg)
            console.log("Email has been sent!")
            res.json({sendedmessage})
        } catch (error) {
            console.log(error)
            res.json({error})
        }
}

module.exports = SendEmail;



