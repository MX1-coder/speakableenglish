
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Getcourses } from '../../../store/actions/coursesActions';
import { GetTeachers, imageUpload, updateTeacher } from '../../../store/actions/teachersActions';
import AdminNav from '../AdminNav';
import TimePicker from 'react-time-picker';
import DatePicker from 'react-datepicker';
import { useNavigate, useParams } from 'react-router-dom';
import moment from 'moment';


const AdminEditTeacher = () => {
  const { id } = useParams();
  console.log(id)
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const courses = useSelector((state) => state.courses.courseslist);
  const teachers = useSelector((state) => state.teachers.AllTeacherlist);
  const currentTeacher = teachers.find((teacher) => teacher._id === id);

  const [formData, setFormData] = useState({
    Username: '',
    Password: '',
    Phone_Number: '',
    Address: '',
    Courses_assign: [],
    Meetings: [],
    Purchase_Price: '',
    Description: '',  
    Short_Title: '',
    Email: '',
    Availability: [
      {
        Date: new Date(),
        Time: [
          {
            Start_time: '10:00',
            End_time: '14:00',
          },
        ],
      },
    ],
    Profile_Image: [],
    SocialLinks: [
      { platform: 'facebook', link: '' },
      { platform: 'twitter', link: '' },
      { platform: 'instagram', link: '' },
      // Add more social media platforms if needed
    ],
  });
  useEffect(() => {
    dispatch(Getcourses());
    dispatch(GetTeachers());
  
    if (currentTeacher) {
      setFormData((prevData) => {
        const formattedAvailability = currentTeacher.Availability.map((availability) => {
          const { date, time } = formatDateTime(availability.Date);
          const startTime = formatDateTime(availability.Time[0].Start_time).time;
          const endTime = formatDateTime(availability.Time[0].End_time).time;
          return {
            Date: date,
            Time: [
              {
                Start_time: startTime,
                End_time: endTime,
              },
            ],
          };
        });
  
        return {
          ...prevData,
          Username: currentTeacher.Username || '',
          Password: currentTeacher.Password || '',
          Phone_Number: currentTeacher.Phone_Number || '',
          Address: currentTeacher.Address || '',
          Courses_assign: currentTeacher.Courses_assign || [],
          Purchase_Price: currentTeacher.Purchase_Price || '',
          Description: currentTeacher.Description || '',
          Short_Title: currentTeacher.Short_Title || '',
          Email: currentTeacher.Email || '',
          Availability: formattedAvailability || [],
          Profile_Image: currentTeacher.Profile_Image || [],
          SocialLinks: currentTeacher.SocialLinks || [
            { platform: 'facebook', link: '' },
            { platform: 'twitter', link: '' },
            { platform: 'instagram', link: '' },
          ],
        };
      });
    }
  }, [dispatch, currentTeacher]);
  // console.log(currentTeacher.Availability)

  const formatDateTime = (dateTimeString) => {
    const date = moment(dateTimeString).format('YYYY-MM-DD');
    const time = moment(dateTimeString, 'YYYY-MM-DD HH:mm').format('HH:mm');
    console.log(date, time);
    return { date, time };
  };
   
   // console.log('Current Teacher Courses_assign:', currentTeacher.Courses_assign);
  // console.log(JSON.stringify(currentTeacher.Courses_assign))

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };


  const handleCheckboxChange = (courseid) => {
    setFormData((prevData) => {
      const isSelected = prevData.Courses_assign.some((course) => course._id === courseid);
      if (isSelected) {
        return {
          ...prevData,
          Courses_assign: prevData.Courses_assign.filter((course) => course._id !== courseid),
        };
      } else {
        return {
          ...prevData,
          Courses_assign: [...prevData.Courses_assign, { _id: courseid }],
        };
      }
    });
  };  

  const handleFileUpload = async (event) => {
    const image = event.target.files[0];
    const uploadResult = await dispatch(imageUpload(image));
    setFormData({
      ...formData,
      Profile_Image: formData.Profile_Image?.length
        ? [...formData.Profile_Image, uploadResult.payload]
        : [uploadResult.payload],
    });
  };

  const handleAddTime = () => {
    setFormData((prevData) => ({
      ...prevData,
      Availability: [
        ...prevData.Availability,
        {
          Date: new Date(),
          Time: [
            {
              Start_time: '00:00',
              End_time: '00:00',
            },
          ],
        },
      ],
    }));
  };

  const handleDateChange = (date, index) => {
    let updatedData = [...formData.Availability];
    updatedData[index].Date = date;
    setFormData({ ...formData, Availability: updatedData });
   };


   const handleTimeChange = (time, index, isStartTime) => {
    setFormData((prevData) => {
      const updatedAvailability = [...prevData.Availability];
      const timeType = isStartTime ? 'Start_time' : 'End_time'; // Fix the typo here
  
      // Check if time is defined before formatting
      const formattedTime = time ? moment(time).format('HH:mm') : '00:00';
      
      if (updatedAvailability[index] && Array.isArray(updatedAvailability[index].Time)) {
        updatedAvailability[index].Time = updatedAvailability[index].Time.map((timeObj, i) => {
          if (i === 0) {
            return {
              ...timeObj,
              [timeType]: formattedTime,
            };
          }
          return timeObj;
        });
      }
  
      return {
        ...prevData,
        Availability: updatedAvailability,
      };
    });
  };
  
    
  const handleDeleteTime = (index) => {
    setFormData((prevData) => {
      const updatedAvailability = [...prevData.Availability];
      updatedAvailability.splice(index, 1);
      return {
        ...prevData,
        Availability: updatedAvailability,
      };
    });
  };

  const handleSocialLinkChange = (index, platform, value) => {
    setFormData((prevData) => {
      const updatedSocialLinks = [...prevData.SocialLinks];
      updatedSocialLinks[index] = {
        ...updatedSocialLinks[index],
        platform,
        link: value,
      };
      return {
        ...prevData,
        SocialLinks: updatedSocialLinks,
      };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const teacherId = id;
    const updatedData = formData;
    try {
      await dispatch(updateTeacher({ teacherId, updatedData }));
      setFormData({
        Username: '',
        Password: '',
        Phone_Number: '',
        Address: '',
        Courses_assign: [],
        Meetings: [],
        Purchase_Price: '',
        Description: '',
        Short_Title: '',
        Email: '',
        Availability: [
          {
            Date: new Date(),
            Time: [
              {
                Start_time: '10:00',
                End_time: '14:00',
              },
            ],
          },
        ],
        Profile_Image: [],
        SocialLinks: [
          { platform: 'facebook', link: '' },
          { platform: 'twitter', link: '' },
          { platform: 'instagram', link: '' },
          // Add more social media platforms if needed
        ],
      });
      navigate('/Admin-Dashboard/Teachers');
    } catch (error) {
      console.error('Error editing teacher:', error);
    }
  };

  const handleImageRemoval = async (val) => {
    setFormData({
      ...formData,
      Profile_Image: [...formData.Profile_Image.filter((img) => img !== val)],
    });
  };
  
  return (
    <>
      <AdminNav />
      <div className='Add_Teachers_main_div'>
        <form onSubmit={handleSubmit}>
          {/* Image div */}
          <div className='Addteacherimage_box'>
            {formData.Profile_Image?.map((md, index) => {
              return (
                <div
                  className="col-6 col-sm-6 col-lg-3 mt-2 mt-md-0 mb-md-0 mb-2"
                  key={index}
                >
                  <a href="#">
                    <img
                      className="w-100 active"
                      src={"http://localhost:3000/images/" + md}
                      alt={`Image ${index + 1}`}
                    />
                  </a>
                  <span
                    className="badge bg-danger badge-pill badge-round ml-1"
                    style={{ cursor: "pointer" }}
                    onClick={() => {
                      handleImageRemoval(md);
                    }}
                  >
                    Delete
                  </span>
                </div>
              );
            })}
          </div>
          {/* Image input Links */}
          {formData.Profile_Image?.length < 10 && (
            <div className="col-6 col-sm-6 col-lg-3 mt-2 mt-md-0 mb-md-0 mb-2">
              <div className="card-body">
                <p style={{ fontSize: "12px" }} className="card-text">
                  Select image file to upload.
                </p>
                {/* Basic file uploader */}
                <input
                  className="form-control"
                  encType="multipart/form-data"
                  type="file"
                  name="images"
                  id="formFile"
                  onChange={handleFileUpload}
                />
              </div>
            </div>
          )}
          <div className='form_group_div  mt-2'>
            {/* Teacher Links */}
            <div className="form-group w-25">
              <input
                type="text"
                className="form-control"
                id="teacherName"
                name="teacherName"
                placeholder='Teacher Name'
                value={formData.Username}
                onChange={handleChange}
                required
              />
            </div>
            {/* Description Links */}
            <div className="form-group w-25 mx-5">
              <input
                type="text"
                className="form-control"
                id="description"
                name="description"
                placeholder='Description'
                value={formData.Description}
                onChange={handleChange}
                required
              />
            </div>
            {/* Phone number Links */}
            <div className="form-group w-25">
              <input
                type="number"
                className="form-control"
                id="phoneNumber"
                name="phoneNumber"
                placeholder='Phone Number'
                value={formData.Phone_Number}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          <div className='form_group_div mt-2'>
            {/* Password Links */}
            <div className="form-group w-25">
              <input
                type="Password"
                className="form-control"
                id="Password"
                name="Password"
                placeholder='Password'
                value={formData.Password}
                onChange={handleChange}
                required
              />
            </div>
            {/* Address Links */}
            <div className="form-group w-25 mx-5">
              <input
                type="text"
                className="form-control"
                id="address"
                name="address"
                placeholder='Address'
                value={formData.Address}
                onChange={handleChange}
                required
              />
            </div>
            {/* Short Title Links */}
            <div className="form-group w-25">
              <input
                type="text"
                className="form-control"
                id="shortTitle"
                placeholder='shortTitle'
                name="shortTitle"
                value={formData.Short_Title}
                onChange={handleChange}
                required
              />
            </div>
          </div>
              <div className='form_group_div mt-2'>
                {/* Course Assign Links */}
                <div className="form-group">
                <label htmlFor="Status">Select Courses</label> &nbsp;&nbsp;
                {courses?.map((values) => (
                <div key={values._id} className="form-check">
                <input
                  type="checkbox"
                  id={values._id}
                  value={values._id}
                  checked={formData.Courses_assign.some((course) => course._id === values._id)}
                  onChange={() => handleCheckboxChange(values._id)}
                  className="form-check-input"
                />
                <label htmlFor={values._id} className="form-check-label">
                  {values.Course_Name}
                </label>
                </div>
              ))}
            </div>
            {/* Purchase Links */}
            <div className="form-group w-25 mx-5">
              <input
                type="number"
                className="form-control"
                id="purchasePrice"
                name="purchasePrice"
                placeholder='Purchase Price'
                value={formData.Purchase_Price}
                onChange={handleChange}
                required
              />
            </div>
            {/* Email Links */}
            <div className="form-group w-25">
              <input
                type="text"
                className="form-control"
                id="Email"
                name="Email"
                placeholder='Email'
                value={formData.Email}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          {/* Social Links */}
          <div className="form-group w-100 mt-2 d-flex justify-content-between">
            {formData.SocialLinks?.map((socialLink, index) => (
              <div key={index} className="social-link-item w-25">
                <div className="form-group justify-content-between">
                  <input
                    type="text"
                    className="form-control "
                    placeholder={socialLink.platform}
                    value={socialLink.link}
                    onChange={(e) =>
                      handleSocialLinkChange(
                        index,
                        socialLink.platform,
                        e.target.value
                      )
                    }
                  />
                </div>
              </div>
            ))}
          </div>
          {/* Availability Links */}
          <div className="form-group mt-2">
            <label htmlFor="availability">Availability</label>
            {formData.Availability?.map((slot, index) => (
              <div key={index} className="availability-item p-2 mb-2">
                <div className="form-group">
                  <label>Date</label>
                  <DatePicker
                    className='mx-2 form-control'
                    selected={slot.Date}
                    onChange={(date) => handleDateChange(date, index)}
                  />
                </div>
                <div className="form-group">
                  <label>Start Time</label>
                  <TimePicker
                      value={slot.Time[index] ? slot.Time[index].Start_time : '00:00'}
                      onChange={(time) => {
                        console.log('TimePicker onChange - Time:', time);
                        handleTimeChange(time, index, true);
                      }}
                  />
                </div>
                <div className="form-group">
                  <label>End Time</label>
                  <TimePicker
                    value={slot.Time[index] ? slot.Time[index].End_time : '00:00'}
                    onChange={(time) => {
                      console.log('TimePicker onChange - Time:', time);
                      handleTimeChange(time, index, false); // Use false for end time
                    }}
                  />
                </div>
                <button
                  type="button" 
                  className="btn btn-danger btn-delete-teacher delete-time"
                  onClick={() => handleDeleteTime(index)}
                >
                  Delete
                </button>
              </div>
            ))}
            <button
              type="button"
              className="btn btn-outline-success btn-add-teacher add-time mb-2"
              onClick={handleAddTime}
            >
              Add Time
            </button>
          </div>
          {/* Submit button */}
          <button type="submit" className="btn btn-outline-success mt-3 w-100">
            Submit
          </button>
        </form>
      </div>
    </>
  );
  
}

export default AdminEditTeacher