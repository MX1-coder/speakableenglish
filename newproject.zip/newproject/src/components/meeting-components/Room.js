import React, { useRef, useEffect } from 'react';
import { ZegoUIKitPrebuilt } from '@zegocloud/zego-uikit-prebuilt';
import { useSelector } from 'react-redux';

const Room = () => {
   const user =  useSelector((state) => state.students.user)
   console.log(user)
   const username = user?.Username
  const meetingContainerRef = useRef(null);

  useEffect(() => {
    const myMeeting = (element) => {
      const appID = 24783095;
      const serverSecret = 'b90794e9ff352031d3df9963b51b710a';
      const kitToken = ZegoUIKitPrebuilt.generateKitTokenForTest(
        appID,
        serverSecret,
        username,
        Date.now().toString(),
        String(username)
      );
      const zc = ZegoUIKitPrebuilt.create(kitToken);
      zc.joinRoom({
        container: element,
        scenario: {
          mode: ZegoUIKitPrebuilt.OneONoneCall,
        },
      });
    };

    if (meetingContainerRef.current) {
      myMeeting(meetingContainerRef.current);
    }
  }, [username]);

  return (
    <div >
      <div ref={meetingContainerRef} />
    </div>
  );
};

export default Room;
