import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

const Booknow = () => {
    const { Package_ID } = useParams()
    console.log(Package_ID)
    const dispatch = useDispatch()
    const user = useSelector((state) => state.students.user)
    const pack = useSelector((state) => state.packages.currentPackage)
    console.log(user)
    console.log(pack)
    const [hash, sethash] = useState('')
    const [TransactionID, setTransactionID] = useState('')
    // const [key, setkey] = useState('')

    const key = 'your_payment_gateway_key';
    const txnid = TransactionID;
    const amount = pack?.Package_Amount;
    const productinfo = 'TEST PRODUCT';
    const firstname = user?.Username ;
    const email = user?.Email;
    const Phone_Number = user?.Phone_Number
    const udf1 = ''; // Additional fields if needed
    const udf2 = ''; // Additional fields if needed

    // sha512(key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5||||||SALT)

    useEffect(() => {
        dispatch(fetchPackage(Package_ID))
        generateTransactionID()
        dispatch(Gethash({
            key:key,
            name:firstname,
            email:email,
            amount:amount,
            productinfo:productinfo,
            transactionID:TransactionID,
        }))    
    }, [dispatch,hash])


    function generateTransactionID (){
        const timestamps = Date.now()
        const randomnum = Math.floor(Math.random()*1000000);
        const merchantPrefix = 'TN'
        const transactionID = `${merchantPrefix}${timestamps}${randomnum}`
        return setTransactionID(transactionID)
    } 
    
    // name, email, amount, productinfo, transactionId,key
    


  return (
    <div>
        <form action='https://test.payu.in/_payment' method='post'>
            <input type="hidden" name="key" value= {key} />
            <input type="hidden" name="txnid" value={txnid} />
            <input type="hidden" name="productinfo" value={productinfo} />
            <input type="hidden" name="amount" value={amount} />
            <input type="hidden" name="email" value={email} />
            <input type="hidden" name="firstname" value={firstname} />
            {/* <input type="hidden" name="surl" value="https://apiplayground-response.herokuapp.com/" /> */}
            {/* <input type="hidden" name="furl" value="https://apiplayground-response.herokuapp.com/" /> */}
            <input type="hidden" name="phone" value={Phone_Number} />
            <input type="hidden" name="hash" value= {hash} />
            <input type="submit" value="submit" />
        </form>
            </div>
  )
}

export default Booknow