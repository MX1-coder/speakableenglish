import React from 'react'

const StudentSetting = () => {
  return (
    <div>StudentSetting</div>
  )
}

export default StudentSetting