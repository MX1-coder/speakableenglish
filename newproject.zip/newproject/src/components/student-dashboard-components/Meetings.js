import React from 'react'

const Meetings = () => {
  return (
    <div>Meetings</div>
  )
}

export default Meetings