import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Signup_Student } from '../store/actions/studentsActions';
import { useNavigate } from 'react-router-dom';

const SignupFormPopup = ({ handleClose }) => {

  
const dispatch = useDispatch()
const [Username, setUsername] = useState("")
const [Password, setPassword] = useState("")
const [Email, setEmail] = useState("")

const SubmitHandler = (e) =>{
  e.preventDefault()
  dispatch(Signup_Student({
    Username:Username,
    Email:Email,
    Password:Password
  }))
  // console.log("----------Student SignUp successful from the landing page ---------")
}



  return (
    <div className="form-popup">
      <div className="form-popup-content">
        {/* Add your signup form fields here, for example: */}
        <form onSubmit={SubmitHandler}>
          <h5>Please SignUp!</h5>
          <div className="form-group-sign">
            {/* <label htmlFor="username">Username:</label> */}
            <input 
            type="text" 
            id="Username"
            name="Username"
            placeholder='Username'
            autoComplete='off'
            value={Username}
            onChange={(e) => setUsername(e.target.value)}
            />
             <input 
            type="Email" 
            id="Email"
            name="Email"
            placeholder='Email'
            autoComplete='off'
            value={Email}
            onChange={(e) => setEmail(e.target.value) }
            />
            <input 
            type="Password" 
            id="Password"
            name="Password"
            placeholder='Password'
            autoComplete='off'
            value={Password}
            onChange={(e) => setPassword(e.target.value) }
            />
          </div>
            <div className='d-flex mt-4'>
                  <button type='submit' className="btn btn-outline-success mx-3">SignUp</button>
                  <button onClick={handleClose} className="btn btn-outline-success mx-3">Close</button>
            </div>
        </form>
        {/* Add other form fields as needed */}
      </div>
    </div>
  );
};

export default SignupFormPopup;
