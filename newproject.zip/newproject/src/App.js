import React, { useEffect } from 'react'
import './App.css';
import Layout from './components/Layout'
import { useDispatch,  } from 'react-redux';
import { async_loaduser } from './store/actions/studentsActions';
import { Route, Routes  } from 'react-router-dom';
// --------------------------------------------------------------------------------------- Main  Imports ------------------
import SceduleMeeting from './components/SceduleMeeting';
import ProtectedRoute from './helpers/ProtectedRoute';
import TeacherDetails from './components/TeacherDetails';
import CourseDetails from './components/CourseDetails';
// --------------------------------------------------------------------------------------- Student Imports ------------------
import Profile from './components/student-dashboard-components/Profile';
import Courses from './components/student-dashboard-components/Courses';
// import Meetings from './components/student-dashboard-components/Meetings';
import StudentDashboard from './components/StudentDashboard';
import StudentDash from './components/student-dashboard-components/StudentDash';
import Feedback from './components/student-dashboard-components/Feedback';
import Packages from './components/student-dashboard-components/Packages';
import Bookings from './components/student-dashboard-components/Bookings';
import Payments from './components/student-dashboard-components/Payments';
import Enquirys from './components/student-dashboard-components/Enquirys';
import StudentSetting from './components/student-dashboard-components/StudentSetting';
// -----------------------------------------------------------------------------------------Admin Imports ------------------
import AdminDash from './components/admin-dashboard-components/AdminDash';
import AdminDashboard from './components/admin-dashboard-components/AdminDashboard';
import AdminTeachers from './components/admin-dashboard-components/AdminTeachers'
import AdminStudents from './components/admin-dashboard-components/AdminStudents'
import AdminCourses from './components/admin-dashboard-components/AdminCourses'
import AdminMeetings from './components/admin-dashboard-components/AdminMeetings'
import Adminfeedbacks from './components/admin-dashboard-components/Adminfeedbacks'
import AdminPackages from './components/admin-dashboard-components/AdminPackages'
import AdminBookings from './components/admin-dashboard-components/AdminBookings'
import AdminPayments from './components/admin-dashboard-components/AdminPayments'
import AdminEnquirys from './components/admin-dashboard-components/AdminEnquirys'
import AdminSettings from './components/admin-dashboard-components/AdminSettings'
import AdminAddTeachers from './components/admin-dashboard-components/AdminAddTeachers'
import AdminAddStudents from './components/admin-dashboard-components/AdminAddStudents';
import AdminAddCourses from './components/admin-dashboard-components/AdminAddCourses';
import AdminEditCourse from './components/admin-dashboard-components/AdminEditPages/AdminEditCourse';
import AdminTeachersDetails from './components/admin-dashboard-components/AdminEditPages/AdminTeachersDetails';
import AdminEditTeacher from './components/admin-dashboard-components/AdminEditPages/AdminEditTeacher';
import AdminStudentsDetails from './components/admin-dashboard-components/AdminEditPages/AdminStudentsDetails';
import AdminEditStudent from './components/admin-dashboard-components/AdminEditPages/AdminEditStudent'
import AdminEditMeetings from './components/admin-dashboard-components/AdminEditPages/AdminEditMeetings';
import AdminAddMeetings from './components/admin-dashboard-components/AdminAddMeetings';
// -------------------------------------------------------------------------Teachers Import -------------------------------
import TeacherDashboard from './components/teacher-dashboard-components/TeacherDashboard';
import TeacherDash from './components/teacher-dashboard-components/TeacherDash';
import TeacherProfile from './components/teacher-dashboard-components/TeacherProfile';
import TeacherCourses from './components/teacher-dashboard-components/TeacherCourses';
import TeacherFeedback from './components/teacher-dashboard-components/TeacherFeedback';
import TeacherPackages from './components/teacher-dashboard-components/TeacherPackages';
import TeacherBookings from './components/teacher-dashboard-components/TeacherBookings';
import TeacherPayments from './components/teacher-dashboard-components/TeacherPayments';
import TeacherEnquirys from './components/teacher-dashboard-components/TeacherEnquirys';
import TeacherSetting from './components/teacher-dashboard-components/TeacherSetting';
// --------------------------------------------------------------------------Accountnat Imports ------------------------------
import AccontantDashboard from './components/acoountant-dashboard-components/AccontantDashboard';
import AccontantDash from './components/acoountant-dashboard-components/AccontantDash';
import AccontantPayment from './components/acoountant-dashboard-components/AccontantPayment';
import AccontantPackage from './components/acoountant-dashboard-components/AccontantPackage';
import AdminAddPackage from './components/admin-dashboard-components/AdminAddPackage';
import AdminEditPackages from './components/admin-dashboard-components/AdminEditPages/AdminEditPackages';
import AdminAddBooking from './components/admin-dashboard-components/AdminAddBooking';
import AdminEditBooking from './components/admin-dashboard-components/AdminEditPages/AdminEditBooking';
import AddStudentEnquiry from './components/student-dashboard-components/AddStudentEnquiry';
import Room from './components/meeting-components/Room';


const App = () => {
  const dispatch = useDispatch();

  // load user 
  useEffect(() => {
    dispatch(async_loaduser());
  },[]);

  return <>
  
  {/* ---------------------------------------------------------------------------------------------------- Main Routes  ------------------------- */}
  
  <Routes>
            <Route 
                path='/'
                element={<Layout/>}
            />
            <Route   
                path ='/Scedule-Meeting'
                element={<SceduleMeeting/>}
            />
            <Route
                path='/TeacherDetails/:TeacherID'
                element={<TeacherDetails/>}
            
            />
            <Route
                path='/CourseDetails/:CourseID'
                element={<CourseDetails/>}
            />

            {/*---------------------------------------------------------------------------------------------- Student Dashboard Routes --------------- */}

            <Route  
                  path ='/Student-dashboard'
                  element={
                    <ProtectedRoute>
                        <StudentDashboard/>
                    </ProtectedRoute>
                  }
                  >
                  <Route
                      path='/Student-dashboard/dash'
                      element={<StudentDash/>}
                  />
                   <Route
                      path='/Student-dashboard/profile'
                      element={<Profile/>}
                  />
                   <Route
                      path='/Student-dashboard/Courses'
                     element={<Courses/>}
                  /> 
                 
                   <Route
                      path='/Student-dashboard/Feedback'
                      element={<Feedback/>}
                  /> 
                   <Route
                      path='/Student-dashboard/Packages'
                      element={<Packages/>}
                  />
                   <Route
                      path='/Student-dashboard/Bookings'
                      element={<Bookings/>}
                  /> 
                   <Route
                      path='/Student-dashboard/Payments'
                      element={<Payments/>}
                  /> 
                   <Route
                      path='/Student-dashboard/Enquirys'
                      element={<Enquirys/>}
                  /> 
                   <Route
                      path='/Student-dashboard/setting'
                      element={<StudentSetting/>}
                  />
                  <Route
                      path='/Student-dashboard/Enquirys/add-enquirys/:StudentID'
                      element={<AddStudentEnquiry/>}
                  />       
            </Route>

            {/* --------------------------------------------------------------------------------------------------------------Teachers Panel Routes ------------- */}

            <Route  
                  path ='/Teacher-dashboard'
                  element={
                    <ProtectedRoute>
                       <TeacherDashboard/>
                    </ProtectedRoute>
                  }
                  >
                  <Route
                      path='/Teacher-dashboard/dash'
                      element={<TeacherDash/>}
                  />
                   <Route
                      path='/Teacher-dashboard/profile'
                      element={<TeacherProfile/>}
                  />
                   <Route
                      path='/Teacher-dashboard/Courses'
                     element={<TeacherCourses/>}
                  /> 
                 
                   <Route
                      path='/Teacher-dashboard/Feedback'
                      element={<TeacherFeedback/>}
                  /> 
                   <Route
                      path='/Teacher-dashboard/Packages'
                      element={<TeacherPackages/>}
                  /> 
                   <Route
                      path='/Teacher-dashboard/Bookings'
                      element={<TeacherBookings/>}
                  /> 
                   <Route
                      path='/Teacher-dashboard/Payments'
                      element={<TeacherPayments/>}
                  /> 
                   <Route
                      path='/Teacher-dashboard/Enquirys'
                      element={<TeacherEnquirys/>}
                  /> 
                   <Route
                      path='/Teacher-dashboard/setting'
                      element={<TeacherSetting/>}
                  />     
            </Route>

            {/* ------------------------------------------------------------------------------------------------------------- Admin Panel Routes  ---------------  */}

            {/* Admin  Dashboard Routes */}
            <Route
                  path='/Admin-Dashboard/'
                  element={
                    <ProtectedRoute>
                      <AdminDashboard/>
                    </ProtectedRoute>
                  }
                >
                  <Route
                      path='/Admin-Dashboard/Dashboard'
                      element={<AdminDash/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Teachers'
                      element={<AdminTeachers/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Teachers/add-teacher'
                      element={<AdminAddTeachers/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Teachers/edit-teacher/:id'
                      element={<AdminEditTeacher/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Teachers/teachersDetails/:id'
                      element={<AdminTeachersDetails/>}
                  />  
                  <Route
                      path='/Admin-Dashboard/Students'
                      element={<AdminStudents/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Students/add-student'
                      element={<AdminAddStudents/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Students/edit-student/:id'
                      element={<AdminEditStudent/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Students/studentsDetails/:id'
                      element={<AdminStudentsDetails/>}
                  />  
                  <Route
                      path='/Admin-Dashboard/Courses'
                      element={<AdminCourses/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Courses/add-courses'
                      element={<AdminAddCourses/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Courses/edit-Courses/:id'
                      element={<AdminEditCourse/>}
                  /> 
                  <Route
                      path='/Admin-Dashboard/Meetings'
                      element={<AdminMeetings/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Meetings/add-meeting'
                      element={<AdminAddMeetings/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Meetings/edit-Meetings/:id'
                      element={<AdminEditMeetings/>}
                  /> 
                  <Route
                      path='/Admin-Dashboard/Feedbacks'
                      element={<Adminfeedbacks/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Packages'
                      element={<AdminPackages/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Packages/add-package'
                      element={<AdminAddPackage/>}
                  />
                   <Route
                      path='/Admin-Dashboard/Packages/edit-package/:PackageID'
                      element={<AdminEditPackages/>}
                  /> 
                  <Route
                      path='/Admin-Dashboard/Bookings'
                      element={<AdminBookings/>}
                  />
                    <Route
                      path='/Admin-Dashboard/Bookings/add-Booking'
                      element={<AdminAddBooking/>}
                  />
                    <Route
                      path='/Admin-Dashboard/Bookings/edit-booking/:BookingID'
                      element={<AdminEditBooking/>}
                  />

                  <Route
                      path='/Admin-Dashboard/Payments'
                      element={<AdminPayments/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Enquirys'
                      element={<AdminEnquirys/>}
                  />
                  <Route
                      path='/Admin-Dashboard/Settings'
                      element={<AdminSettings/>}
                  />
                  {/* <Route
                      path='/Admin-Dashboard/Logout'
                      element={<AdminTeachers/>}
                  /> */}
            </Route>

            {/* -----------------------------------------------------------------------------------------------Accoutant Routes */}

            <Route
                  path='/Accontant-Dashboard/'
                  element={
                    <ProtectedRoute>
                       <AccontantDashboard/>
                    </ProtectedRoute>
                         }
                   >
                  <Route
                      path='/Accontant-Dashboard/dash'
                      element={<AccontantDash/>}
                  />
                  <Route
                      path='/Accontant-Dashboard/Payments'
                      element={<AccontantPayment/>}
                  />
                   <Route
                      path='/Accontant-Dashboard/Package'
                      element={<AccontantPackage/>}
                  />
            </Route>

            <Route 
            path='rooom/meeting'
            element={<Room/>}
            />
</Routes>    
</> 
}

export default App