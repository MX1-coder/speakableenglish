var express = require("express");
var router = express.Router();
const multer = require("multer");
const path = require("path");
const directpath = path.join(__dirname, "../public/images");
const isAuthorizedUser = require("../middleware/auth");

const {
  index,
  Signup_Student,
  Signin_Student,
  Signin_Teacher,
  Create_Enquiry_Student,
  Fetch_Enquiry_Student,
  Delete_Enquiry_Student,
  Update_Enquiry_Student,
  Signin_admin,
  Signup_admin,
  Signup_user,
  Signin_user,
  Create_Meeting,
  Join_Meeting,
  Delete_Meeting,
  FetchAll_Students,
  currentAdmin,
  signout,
  Fetch5Teachers,
  TeacherDetails,
  Fetch5courses,
  Create_Course,
  Fetch1teacher,
  courseDetails,
  Delete_Student,
  Update_Student,
  Delete_Teacher,
  Update_Teacher,
  Update_Meeting,
  Delete_Course,
  Update_Course,
  getstudentbyID,
  getteachers,
  getteacherbyID,
  getmeetings,
  getenquiries,
  getcourses,
  imageupload,
  Delete_Feedback,
  Update_Feedback,
  getfeedback,
  Create_Booking,
  Delete_Booking,
  Update_Booking,
  getbookings,
  Add_Feedback,
  StudentDetails,
  Signup_accountant,
  Add_Payment,
  Delete_Payment,
  Add_Package,
  Delete_Package,
  Update_Package,
  getpackages,
  getpayments,
  Create_Enquiry,
  Fetch_Single_Package,
  GetBookingsByStudentID,
  GetBookingsByTeacherID,
  GetCourseByID,
  GetPackageByTeacherID,
  GetPaymentsByStudentID,
  Signup_Student_By_Admin,
  Signup_Teacher_By_Admin,
  Gethash,
  Get_Notifications_by_id,
  DeleteNotification_by_id,
  NotificationsOfAdmin,
  NotificationsOfAccountant,
  Make_Payment,
  Payment_Notification,
  FindUserByEmail,
  MatchOTP,
  Reset_Password,
  authorizepaymnet,
  authorizePayment,
} = require("../controllers/indexContoller");

// ---------------- Multer Routes For Uploading Images ---------------------------------------------------

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// ------------------------------------------------------------------------- Routes ----------------------

router.get("/", index);

//@api- post/me -- For load user
router.post("/api/me", isAuthorizedUser, currentAdmin);

router.get("/api/signout", signout);

router.post("/api/FindUserByEmail", FindUserByEmail);
router.post("/api/MatchOTP", MatchOTP);
router.post("/api/Reset_Password", Reset_Password);
// ------------------------------------------------------------------------- Accountant Routes -----------

router.post("/api/Signup_accountant", Signup_accountant);

// ------------------------------------------------------------------------- User Routes -----------------

router.post("/api/Signup_user", Signup_user);

router.post("/api/Signin_user", Signin_user);

// -------------------------------------------------------------------------  Admin Routes ---------------

router.post("/api/Signup_admin", Signup_admin);

router.post("/api/Signin_admin", Signin_admin);

// --------------------------------------------------------------------------  Student Routes ------------

router.post("/api/Signup_Student", Signup_Student);

router.post("/api/Signup_Student_By_Admin", Signup_Student_By_Admin);

router.post("/api/Signin_Student", Signin_Student);

router.get("/api/Delete_student/:student_ID", Delete_Student);

router.get("/api/FetchAll_students", FetchAll_Students);

router.post("/api/Update_Student/:StudentID", Update_Student);

router.get("/api/fetchStudentDetails/:StudentID", StudentDetails);

// -------------------------------------------------------------------------- Teachers Routes ------------

router.post("/api/Signup_Teacher_By_Admin", Signup_Teacher_By_Admin);

router.post("/api/Signin_Teacher", Signin_Teacher);

router.get("/api/Delete_teacher/:teacher_ID", Delete_Teacher);

router.post("/api/Update_Teacher/:TeacherID", Update_Teacher);

router.get("/api/getteachers", getteachers);

// -------------------------------------------------------------------------- Enquiry Routes --------------

router.get("/api/Fetch_Enquiry_Student/:Email", Fetch_Enquiry_Student);

router.post("/api/Create_Enquiry_Student/:StudentID", Create_Enquiry_Student);

router.get("/api/Delete_Enquiry_Student/:EnquiryID", Delete_Enquiry_Student);

router.post(
  "/api/Update_Enquiry_Student/:StudentID/:EnquiryID",
  Update_Enquiry_Student
);

router.get("/api/getenquiries", getenquiries);

router.post("/api/Create_Enquiry", Create_Enquiry);

// -------------------------------------------------------------------------- Meeting Routes --------------

router.post("/api/Create_Meeting/:CreatedBy_ID", Create_Meeting);

router.post("/api/Join_Meeting/:userId/:meetingId", Join_Meeting);

router.get("/api/Delete_meeting/:meeting_ID", Delete_Meeting);

router.post("/api/Update_Meeting/:MeetingID", Update_Meeting);

router.get("/api/getmeetings", getmeetings);

// -------------------------------------------------------------------------  Fetch Routes  -------------------

router.get("/api/Fetch5Teachers", Fetch5Teachers);

router.get("/api/Fetch1teacher", Fetch1teacher);

router.get("/api/fetchTeacherDetails/:TeacherID", TeacherDetails);

router.get("/api/fetchcourseDetails/:CourseID", courseDetails);

// ------------------------------------------------------------------------  Courses Routes  ---------------------

router.get("/api/Fetch5courses", Fetch5courses);

router.post("/api/Create_Course", Create_Course);

router.get("/api/Delete_course/:CourseID", Delete_Course);

router.post("/api/Update_Course/:CourseID", Update_Course);

router.get("/api/getcourses", getcourses);

// -------------------------------------------------------------------------  Feedback Routes  -------------------------

router.post("/api/Add_Feedback", Add_Feedback);

router.get("/api/Delete_Feedback/:FeedbackID", Delete_Feedback);

router.post("/api/Update_Feedback/:FeedbackID", Update_Feedback);

router.get("/api/getfeedback", getfeedback);

// -------------------------------------------------------------------------  Booking Routes  -------------------------

router.post("/api/Create_Booking", Create_Booking);

router.get("/api/Delete_Booking/:BookingID", Delete_Booking);

router.post("/api/Update_Booking/:BookingID", Update_Booking);

router.get("/api/getbookings", getbookings);

// -------------------------------------------------------------------------  Payment Routes  -------------------------

router.post("/api/Add_Payment", Add_Payment);

router.get("/api/Delete_Payment/:PaymentID", Delete_Payment);

router.get("/api/getpayments", getpayments);

// -------------------------------------------------------------------------  Package Routes  -------------------------

router.post("/api/Add_Package", Add_Package);

router.get("/api/Delete_Package/:PackageID", Delete_Package);

router.post("/api/Update_Package/:PackageID", Update_Package);

router.get("/api/getpackages", getpackages);

router.get("/api/fetchPackage/:PackageID", Fetch_Single_Package);

// -------------------------------------------------------------------------  Get Routes  -------------------------

router.get("/api/getstudentbyID/:StudentID", getstudentbyID);

// -------------------------------------------------------------------------------------------------------------------

router.post("/api/update-image", upload.single("image"), imageupload);

router.get("/api/GetBookingsByStudentID/:StudentID", GetBookingsByStudentID);

router.get("/api/GetBookingsByTeacherID/:TeacherID", GetBookingsByTeacherID);

router.get("/api/GetCourseByID/:CourseID", GetCourseByID);

router.get("/api/GetPackageByTeacherID/:TeacherID", GetPackageByTeacherID);

router.get("/api/GetPaymentsByStudentID/:StudentID", GetPaymentsByStudentID);

router.post("/api/Gethash", Gethash);

router.get("/api/Get_Notifications/:id", Get_Notifications_by_id);

router.get("/api/DeleteNotification/:id", DeleteNotification_by_id);

router.get("/api/NotificationsOfAdmin", NotificationsOfAdmin);

router.get("/api/NotificationsOfAccountant", NotificationsOfAccountant);

router.post("/api/Make-Payment", Make_Payment);

router.post("/api/Payment_Notification", Payment_Notification);

router.get("/api/authorizePayment/:orderId" , authorizePayment)

module.exports = router;
