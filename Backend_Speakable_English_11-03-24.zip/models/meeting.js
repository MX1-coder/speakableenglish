const mongoose = require('mongoose');

const meetingSchema = mongoose.Schema({
  Attendee_ID: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "student",
  }],
  Teacher_ID: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "teacher"
  },
  Joining_Url: {
    type: String,
  },
  Status: {
    type: String,
    required: true,
  },
  Created_By: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "student",
  },
});

const Meeting = mongoose.model('Meeting', meetingSchema);

module.exports = Meeting;
