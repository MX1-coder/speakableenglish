import React, { useRef, useState } from "react";
import { useDispatch } from "react-redux"; // Added import
import ReCAPTCHA from "react-google-recaptcha";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { Signup_Student } from "../../store/actions/studentsActions";
import { useTranslation } from "react-i18next";

const About = () => {
  const dispatch = useDispatch();
  const [t, i18n] = useTranslation("global");
  const [Username, setUsername] = useState("");
  const [Password, setPassword] = useState("");
  const [Email, setEmail] = useState("");
  const [Phone_Number, setPhone_Number] = useState("");
  const [verified, setverified] = useState(false);
  const [recaptcha, setrecaptcha] = useState("");
  const recaptcheref = useRef();

  const SubmitHandler = async (e) => {
    e.preventDefault();
    await dispatch(
      Signup_Student({
        Username: Username,
        Email: Email,
        Phone_Number: Phone_Number,
        Password: Password,
        recaptcha,
      })
    );
    await recaptcheref.current.reset();
    setTimeout(() => {
      window.location.reload();
    }, 2000); // Add a delay of 1 second (1000 milliseconds) before reloading
  };

  const onChange = (value) => {
    console.log("Captcha value:", value);
    setrecaptcha(value);
    setverified(true);
  };

  return (
    <div className="col-md-12 About_main_div" id="About">
      <div className="col-md-10  About_main_column_div">
        <div className="col-md-6 col-sm-12 About_main_column_left_div">
          <h2>{t("About.leftheading")}</h2>
          <div className="w-100 About_main_column_left_div_col">
            <span>
              <i class="bi bi-people-fill"></i>
            </span>
            <div className="About_main_column_left_div_col_right">
              <h3>{t("About.leftSub1")}</h3>
              <p>{t("About.leftSubpara1")}</p>
            </div>
          </div>
          <div className="w-100 About_main_column_left_div_col mt-2">
            <span>
              <i class="bi bi-people-fill"></i>
            </span>
            <div className="About_main_column_left_div_col_right">
              <h3>{t("About.leftSub2")}</h3>
              <p>{t("About.leftSubpara2")}</p>
            </div>
          </div>
          <div className="w-100 About_main_column_left_div_col mt-2">
            <span>
              <i class="bi bi-people-fill"></i>
            </span>
            <div className="About_main_column_left_div_col_right">
              <h3>{t("About.leftSub3")}</h3>
              <p>
              {t("About.leftSubpara3")}
              </p>
            </div>
          </div>
        </div>
        <div className="col-md-offset-1 col-md-5 col-sm-12 About_main_column_right_div">
          <div className="About_main_column_right_form_div mt-2">
            <h2>{t("About.Signuptoday")}</h2>
            <form onSubmit={SubmitHandler}>
              <input
                className=" w-100 input_style"
                placeholder={t("About.Fullname")}
                type="text"
                id="Username"
                name="Username"
                autoComplete="off"
                value={Username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
              <input
                className=" w-100 input_style"
                placeholder={t("About.YourEmailaddress")}
                type="Email"
                id="Email"
                name="Email"
                autoComplete="off"
                value={Email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <PhoneInput
                country={"us"}
                className="mt-2"
                value={Phone_Number}
                onChange={(phone, country, e, formattedValue) => {
                  // console.log(formattedValue)
                  setPhone_Number(formattedValue);
                }}
                inputProps={{
                  name: "Phone_number",
                  required: true,
                  autoFocus: true,
                  className: "form-control phonenumberinput",
                }}
                required
              />
              <input
                className=" w-100 input_style"
                placeholder={t("About.YourPassowrd")}
                type="Password"
                id="Password"
                name="Password"
                autoComplete="off"
                value={Password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <ReCAPTCHA
                sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"
                onChange={onChange}
                ref={recaptcheref}
              />
              <button type="submit" className="btn btn-outline-light mt-3">
                {t("About.GetStarted")}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
